<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asset extends Model
{
    public $timestamps = false;
    protected $fillable = ["name","asset_type","hosting_type","hosting_provider","country","city","state","lng","lat","client_id","it_owner","business_owner","internal_3rd_party","data_subject_volume"];
}
