<?php

namespace App\Imports;

use App\Asset;
use Maatwebsite\Excel\Concerns\ToModel;

class AssetsImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        
        return new Asset([
            "name" => $row[0],
            "asset_type" => $row[1],
            "hosting_type" => $row[2],
            "hosting_provider" => $row[3],
            "country" => $row[4],
            "city" => $row[5],
            "state" => $row[6],
            "lng" => $row[7],
            "lat" => $row[8],
            "client_id" => $row[9],
            "it_owner" => $row[10],
            "business_owner" => $row[11],
            "internal_3rd_party" => $row[12],
            "data_subject_volume" => $row[13],
        ]);
    }
}
