<?php

namespace App\Exports;

use App\Asset;
use Maatwebsite\Excel\Concerns\FromCollection;

class AssetsExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
         return Asset::select("name","asset_type","hosting_type","hosting_provider","country","city","state","lng","lat","client_id","it_owner","business_owner","internal_3rd_party","data_subject_volume")->orderby("id","desc")->get();
    }
}
