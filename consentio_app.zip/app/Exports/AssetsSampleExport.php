<?php

namespace App\Exports;

use App\Asset;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class AssetsSampleExport implements FromCollection,WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
     public function headings():array{
        return [
            "name","asset_type","hosting_type","hosting_provider","country","city","state","lng","lat","client_id","it_owner","business_owner","internal_3rd_party","data_subject_volume",];

     }

    public function collection()
    {
        return Asset::select("name","asset_type","hosting_type","hosting_provider","country","city","state","lng","lat","client_id","it_owner","business_owner","internal_3rd_party","data_subject_volume")->where("id",95)->orderby("id","desc")->get();
    }
}
