<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use App\User;
use Validator;
use App\Exports\AssetsExport;
use App\Exports\AssetsSampleExport;
use App\Imports\AssetsImport;
use Maatwebsite\Excel\Facades\Excel;

class AssetsController extends Controller
{
    public function __construct()
    {
   
    }
    public function tests ()
	{
        echo 'here';exit;
        return view('admin.client.test');
	}
    public function asset_data_elements(){
        $user_id  = Auth::user()->id;
        $data = DB::table("assets_data_elements as ade ")->where("owner_id",$user_id)->get();
        $section = DB::table("sections")->get();
        $dc_data = DB::table("data_classifications")->get();
        //dd($dc_data);
        return view("assets.asset_data_element",["data"=>$data,"dc_data"=>$dc_data,"section"=>$section]);
    }
    public function asset_elements_update(Request $req){
        /*echo "<pre>";print_r($req->all());exit;*/
         $d_id = $_POST['ae_id'];
         $d_c = $_POST['d_c_id'];
         $asset_name = $_POST['asset_name'];

          DB::table("assets_data_elements")
            ->where("id",$d_id)
            ->update([
                "name" => $asset_name,
                "d_classification_id" => $d_c,
                "section_id" => $req->section,
            ]);
    }

    public function index (Request $req)
    {   
        

        if($req->imp && $req->dc_val){
            $impact = $req->imp; 
            $dc_value = $req->dc_val;

            $asset_matrix = DB::table("asset_tier_matrix")->where("impact_id",$impact)->where("data_classification_id",$dc_value)->get();
            return $asset_matrix;
        }else{
            $user = Auth::user()->id;
                $assigned_permissions =array();
                $data = DB::table('module_permissions_users')->where('user_id' , $user)->pluck('allowed_module');

                if($data != null){
                     foreach ($data as $value) {
                    $assigned_permissions = explode(',',$value);
                     
                }
                }
                if(!in_array('Assets List', $assigned_permissions)){
                    return redirect('dashboard');
                }
             
             $asset_data_element = DB::table("assets_data_elements")->get();
             //dd($asset_data_element);
            $client_id = Auth::user()->client_id;
            $asset_list = DB::table('assets')->whereNotNull('name')->where('client_id', $client_id)->orderBy('name','ASC')->get();
            $countries = DB::table('countries')->get();
            $impact = DB::table("impact")->get();
            $dt_classification = DB::table("data_classifications")->get();
                
            return view('assets.assets', ["asset_data_element"=>$asset_data_element,"impact"=>$impact,"dt_classification"=>$dt_classification,'asset_list' => $asset_list, 'countries' => $countries, 'user_type' => (Auth::user()->role == 1)?('admin'):('client')]);
        }
    }
    public function view_assets($id){
        $data = DB::table('assets')->where('id',$id)->get()->first();
        $cont = DB::table('countries')->where('country_name',$data->country)->get();
        $countries = DB::table('countries')->get();
        
        return view('assets.view_assets',['data' => $data, 'cont' => $cont, 'countries' => $countries, 'user_type' => (Auth::user()->role == 1)?('admin'):('client')]);
    }
    
    public function add_asset (Request $request)
    {

        $asset = $request->input('asset');
        $client_id = Auth::user()->client_id;
        $status = 'error';
        $title  = __('The asset could not be added');
        $msg    = __('Something went wrong while inserting the asset');      
        
        if (DB::table('assets')->where('name', trim($asset))->exists())
        {
            $status = 'error';
            $title  = __('Duplicate Asset');
            $msg    = __('This asset is already present');
        }
        else
        {
            if (DB::table('assets')->insert(['name' => trim($asset) , 'client_id' => $client_id]))
            {
                $status = 'success';
                $title  = __('Asset Added');
                $msg    = __('Asset Added successfully!');                
            }
        }
 

        return response()->json(['status' => $status, 'title' => $title, 'msg' => $msg]);
    }

    public function asset_update(Request $request){
        $name = $request->name;

        if (DB::table('assets')->where('name',$request->first_name)->update(['name' => $name]))
            {
                return redirect()->back()->with('message', __('Asset Updated successfully!'));                
            }

        return redirect()->back()->with('message', __('Asset Updated Unsuccessfully!'));
    }

    public function asset_delete($id){

        if (DB::table('assets')->where('id',$id)->delete())
            {
                return redirect()->back()->with('message', __('Asset Delete successfully!'));                
            }

        return redirect()->back()->with('message', __('Asset Delete Unsuccessfully!'));
    }
    

    public function asset_add(Request $request){
       /* $db_value = $request->impact;
        dd($db_value);*/

        $request->validate([
            'name' => 'required|max:255',
            'hosting_provider' => 'required',
            ],
            [
            'name.required' => __('Please provide proper asset name to proceed.'),
            'hosting_provider.required' => __('Please Provide Hosting Provider.')
            ]
            );
        
        $client_id = Auth::user()->client_id;

        if (DB::table('assets')->where('name', $request->name)->where('client_id' , '=' , $client_id)->exists())
        {
        $status = 'error';
        $title  = __('Already Exists');
        $msg    = __('The requested asset was already exists');            

        return response()->json(['status' => $status, 'title' => $title, 'msg' => $msg]);
        // return response()->json($request);
        }

       $asset_record =  DB::table('assets')->insert([
                'asset_type' => $request->asset_type,
                'name' => $request->name ,
                'hosting_type' => $request->hosting_type ,
                'hosting_provider' => $request->hosting_provider ,
                'country' => $request->country ,
                'city' => $request->city , 
                'state' => $request->state , 
                'lng' => $request->lng , 
                'lat' => $request->lat , 
                'client_id' => $client_id,
                'it_owner' => $request->it_owner,
                'business_owner' => $request->business_owner,
                'internal_3rd_party' => $request->internal_or_3rd_party,
                'data_subject_volume' => $request->data_subject_vol
            ]);
                            // return redirect()->back()->with('message','Added successfully..!');
            $status = 'success';
            $title  = __('Added');
            $msg    = __('The requested asset was successfully added');            

            return response()->json(['status' => $status, 'title' => $title, 'msg' => $msg]);
            return response()->json($request);

            $client_id = Auth::user()->client_id;

            if (DB::table('assets')->where('client_id' , '!='  , $client_id)->where('name', $request->name)->exists())
            {
                return redirect()->back()->with('message', __('This asset is already present!'));
            }
            else
            {
                if($request->hasfile('image')){
                    $image = $request->file('image');
                    $imageName = time() . "." .$image->extension();
                    $imagePath = public_path() . '/img';
                    $image->move($imagePath, $imageName);
                    $imageDbPath = $imageName;
                }

                if (DB::table('assets')->insert([
                    'asset_type' => $request->asset_type,
                    'name' => $request->name ,
                    'hosting_type' => $request->hosting_type ,
                    'hosting_provider' => $request->hosting_provider ,
                    'country' => $request->country ,
                    'city' => $request->city , 
                    'state' => $request->state , 
                    'lng' => $request->lng , 
                    'lat' => $request->lat , 
                    'client_id' => $client_id

                ]))

                {
                    return redirect()->back()->with('message', __('Asset Added successfully!'));                
                }   
            }
            return redirect()->back()->with('message', __('Request Denide!'));
        }

    public function asset_edit(Request $request,$id){

         if($request->imp && $request->dc_val){
            $impact = $request->imp; 
            $dc_value = $request->dc_val;

            $asset_matrix = DB::table("asset_tier_matrix")->where("impact_id",$impact)->where("data_classification_id",$dc_value)->get();
            return $asset_matrix;
        }else{

            $data = DB::table('assets')->where('id',$id)->get()->first();
            $cont = DB::table('countries')->where('country_name',$data->country)->get();
            // dd($cont);
            $countries = DB::table('countries')->get();
            $impact = DB::table("impact")->get();
            $dt_classification = DB::table("data_classifications")->get();
            // dd($data);
            return view('assets.assets', ["impact"=>$impact,"dt_classification"=>$dt_classification,'data' => $data, 'cont' => $cont, 'countries' => $countries, 'user_type' => (Auth::user()->role == 1)?('admin'):('client')]);
        }

    }

    public function update_asset(Request $request)
    {   

        $request->validate([
            'name' => 'required|max:255',
            'hosting_provider' => 'required',
            ],
            [
            // 'name.required' => 'Please provide proper asset name to proceed.',
            'hosting_provider.required' => __('Please Provide Hosting Provider.')
            ]
            );

        DB::table('assets')->where('id',$request->id)->update([
                'asset_type' => $request->asset_type,
                'hosting_type' => $request->hosting_type ,
                'hosting_provider' => $request->hosting_provider ,
                'country' => $request->country ,
                'city' => $request->city , 
                'lng' => $request->lng , 
                'lat' => $request->lat , 
                'state' => $request->state,
                'it_owner' => $request->it_owner,
                'business_owner' => $request->business_owner,
                'internal_3rd_party' => $request->internal_or_3rd_party,
                'data_subject_volume' => $request->data_subject_vol

            ]);

        $status = 'success';
        $title  = __('Removed');
        $msg    = __('The requested asset was successfully removed');            

        return response()->json(['status' => $status, 'title' => $title, 'msg' => $msg]);

        return response()->json($request);

        // $res_data =  Http::get('https://maps.googleapis.com/maps/api/geocode/json?address=Pakistan+Islamabad&key=AIzaSyDaCml5EZAy3vVRySTNP7_GophMR8Niqmg')->json();

        // dd($request->all());

        if($request->hasfile('image')){
                $image = $request->file('image');
                $imageName = time() . "." .$image->extension();
                $imagePath = public_path() . '/img';
                $image->move($imagePath, $imageName);
                $imageDbPath = $imageName;

                if (DB::table('assets')->where('id',$request->id)->update([
                'asset_type' => $request->asset_type,
                'hosting_type' => $request->hosting_type ,
                'hosting_provider' => $request->hosting_provider ,
                'country' => $request->country ,
                'city' => $request->city , 
                'state' => $request->state

            ])){
                    return redirect('assets')->with('message', __('Asset Updated successfully!'));
                }
            }
            else
            {
                if (DB::table('assets')->where('id',$request->id)->update([
                'asset_type' => $request->asset_type,
                'hosting_type' => $request->hosting_type ,
                'hosting_provider' => $request->hosting_provider ,
                'country' => $request->country ,
                'city' => $request->city , 
                'state' => $request->state

            ])){
                    return redirect('assets')->with('message', __('Asset Updated successfully!'));
                }
                return redirect('assets')->with('message', __('Asset Updated successfully!'));
            }
    }
    public function delete_asset (Request $request)
    {
        $asset_id = $request->id;
        $status = 'error';
        $title  = __('Unable to Delete');
        $msg    = __('You are not allowed to perform this operation');        
        
        
        DB::table('assets')->where('id', $asset_id)->delete();
        $status = 'success';
        $title  = __('Removed');
        $msg    = __('The requested asset was successfully removed');            

        return response()->json(['status' => $status, 'title' => $title, 'msg' => $msg]);
    }
    public function exportAssets(){
         return Excel::download(new AssetsExport, 'assets.xlsx');
    }
    public function importAssets(){
        return view('assets.import');
    }
    public function importAssetsData(Request $req){
        
         Excel::import(new AssetsImport, $req->file('import_file'));

        return redirect('assets')->with("success","Your are successfully Imported");
    }
    public function exportSampleData(){
        return Excel::download(new AssetsSampleExport, 'sample.xlsx');
        return redirect('import-asset')->with("success","Your are successfully Sample Exported");
    }
}