<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Assets_data_element extends Model
{
    //
}
