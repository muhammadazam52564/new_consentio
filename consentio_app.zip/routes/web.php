<?php

use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
// use Illuminate\Support\Facades\Hash;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// GRC

/*
if (isset($_SERVER['HTTP_CLIENT_IP']))
{
    $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
}

if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
{
    $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
}
else
{
    $real_ip_adress = $_SERVER['REMOTE_ADDR'];
}

$cip = $real_ip_adress;

$iptolocation = 'http://api.hostip.info/country.php?ip=' . $cip;
$creatorlocation = file_get_contents($iptolocation);
if($creatorlocation=='PK'){}else{
    //echo 'still under process';exit;
}


*/

//echo 'top';exit;

Route::get('/test_work',function(){
     // dd(DB::table('user_forms')->first());
    $query="ALTER TABLE user_forms
    ADD COLUMN updated_at VARCHAR(25) DEFAULT Null ";
    DB::select($query);
// $var=User::where('email','xaeem.ds@gmail.com')->update(['is_email_varified' => 1]);


// $var1=DB::table('users')->where('email','smalltime59@yahoo.com')->get();
// dd($var1,$var);
// Session::flush();
// $data=User::where('email','ispal@yahoo.com')->first();
// $data->delete();
// dd("yes");
});

Route::get('report_export/{cat_id}' , 'Reports@export_detail_data')->middleware(['auth' , '2fa' , 'is_email_varified']);
Route::get('language/{lang}', function($lang){
        \Session::put('locale', $lang);
        return redirect()->back();
        })->middleware('language');
       
        


Route::get('send_code'  , 'UsersController@send_code')->middleware(['auth' , '2fa']);
Auth::routes();

Route::get('/', function () {
    // return view('auth.login');
   
    return redirect('/login');
});
Route::get('/__clear__', function(){

Artisan::call('cache:clear');
Artisan::call('route:clear');
Artisan::call('config:clear');
Artisan::call('route:cache');
Artisan::call('config:cache');
Artisan::call('view:clear');



return 'cache cleard';
});
Route::get('/info' , function(){
    // dd(App::VERSION());
});


// Route::get('/_user_pass' , function(){

//     $_user_data = DB::table('users')->select('password' , 'name' , 'email','id')->get();
//     foreach ($_user_data as $value) {
        
//                   $chars =  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.
//                             '0123456789`-=~!@#$%^&*()_+,./<>?;:[]{}\|';
//                   $str = '';
//                   $length = 15;
//                   $max = strlen($chars) - 1;

//                       for ($i=0; $i < $length; $i++)
//                         {
//                             $str .= $chars[mt_rand(0, $max)];
//                         }

                   
//                   if($value->email != NULL){
//                            DB::table('users')->where('id' , $value->id)->update([
//                             'new_pass' => $str,
//                             'password' => Hash::make($str),
//                            ]);
//                    }     
//                   $value->new_pass = $str;
 
//     }
//     echo '<pre>';
//     print_r($_user_data);
// });
// Route::get('__clear__', function(){

// Artisan::call('cache:clear');
// Artisan::call('route:clear');
// Artisan::call('config:clear');
// Artisan::call('route:cache');

// // return redirect()->back();

// });
// Route::get('/__routeList' , function(){
//     dd(Artisan::call('route:list'));
// });

Route::prefix("test")->group(function () {
    Route::get("/check-email", function () {

        /*Mail::raw("Hello world !", function ($message) {
            $message->to("adnanafzal565test@gmail.com");
        });*/

        return "check email";
    });
});


/* Route::get('/home', function(){
    if (Auth::user()->role == 1)
    {
        return redirect('/admin');
    }
    if (Auth::user()->role == 2)
    {
        return redirect(route('forms_list'));
    }
}); */

// Route::group(["middleware" => 'user'], function () {


Route::get('users_management','Forms@users_management')->middleware(['auth','2fa', 'is_email_varified' ]);

Route::get('/verify-your-email' , function(){
    if(auth()->user()->is_email_varified == 1){
        return redirect('dashboard');
    }
    return view('login_mail_verify');
})->middleware(['auth','2fa']);



Route::get('add_user','Forms@add_user')->middleware(['auth','2fa', 'is_email_varified']);
Route::get('edit_user/{id}','Forms@edit_user')->middleware(['auth','2fa','is_email_varified']);
Route::post('users/change_status', 'Forms@change_status')->middleware(['auth','2fa','is_email_varified']);
Route::post('store_user', 'Forms@store_user')->middleware(['auth','2fa','is_email_varified']);
Route::post('delete_user', 'Forms@delete_user')->middleware(['auth','2fa','is_email_varified']);
Route::post('store_edit/{id}', 'Forms@store_edit')->middleware(['auth','2fa','is_email_varified']);

/*     IncidentRegister Routes       */
  Route::get('/incident', 'IncidentRegisterController@index')->middleware(['auth', 'is_email_varified']);
  Route::get('/add_inccident','IncidentRegisterController@create')->middleware(['auth','is_email_varified']);
  Route::post('/save_inccident', 'IncidentRegisterController@add')->middleware(['auth','is_email_varified']);
  Route::get('/edit_incident/{id}', 'IncidentRegisterController@edit_incident')->middleware(['auth','is_email_varified']);
  Route::post('/update_inccident', 'IncidentRegisterController@add')->middleware(['auth','is_email_varified']);
  Route::post('/incident/delete', 'IncidentRegisterController@destroy');


Route::get('home', function(){
    return redirect('dashboard');
})->name('home');

Route::get('/test','HomeController@test')->name('test');
Route::post('/tests','HomeController@tests')->name('tests');
Route::post('/login_post','HomeController@login_post')->name('login_post'); 
Route::get('/reload-captcha', 'HomeController@reloadCaptcha');

Route::get('/login','Auth/LoginController@login')->name('login');
Route::get('/dashboard','UsersController@dashboard')->middleware(['auth','is_email_varified'])->name('dashboard');
Route::get('/dashboard-new','UsersController@dashboard_2')->name('new-dashboard');
Route::get('/2fa','PasswordSecurityController@show2faform');

Route::post('/2fa','PasswordSecurityController@enable2fa')->name('enable2fa');
Route::post('/generate2fasecret','PasswordSecurityController@generate2fasecret')->name('generate2fasecret');
Route::post('/disable2fa','PasswordSecurityController@disable2fa')->name('disable2fa');
Route::get('/myredirect','HomeController@my_redirect')->name('myredirect');

Route::get('Forms/UserForm/{id}','Forms@show_form')->name('user_form_link');

Route::get('Forms/CompanyUserForm/{link_id}','Forms@in_users_show_form')->name('user_form_link')->middleware(['auth','2fa','is_email_varified']);

Route::post('Forms/AjaxSubmitExtUserForm','Forms@ajax_ext_user_submit_form')->name('ajax_ext_user_submit_form');

Route::post('Forms/AjaxSubmitUserForm','Forms@ajax_int_user_submit_form')->name('ajax_int_user_submit_form');

Route::post('Forms/LockUserForm','Forms@ajax_lock_user_form')->name('ajax_lock_user_form');

Route::get('Forms/FormSuccess','Forms@show_success_msg')->name('show_success_msg');

Route::get('/Forms/UserFormsList','Forms@forms_list')->name('forms_list')->middleware(['auth','2fa','is_email_varified']);

Route::get('/Forms/CompanyUsersSubFormsList/{id}','Forms@subforms_email_list')->middleware(['auth','2fa','is_email_varified'])->name('send_subforms_list');

Route::get('/Forms/OrgSubFormsList/{id}','Forms@organization_all_forms_list')->middleware(['auth','2fa','is_email_varified'])->name('org_all_forms_list');
Route::get('/all_generated_forms','Forms@organization_all_forms_list_all') ->middleware(['auth','2fa','is_email_varified'])->name('all_generated_forms');     

Route::get('Forms/UserForm/{client_id}/{user_id}/{client_email}/{subform_id}/{user_email}/{date_time}','Forms@show_form')->name('user_form_link');

Route::get('Forms/ExtUserForm/{client_id}/{user_id}/{client_email}/{subform_id}/{user_email}/{date_time}','Forms@ex_users_show_form')->name('ext_user_form_link');

Route::get('/Forms/ExtUserSendSubFormsList/{id}','Forms@ext_users_subforms_email_list')->name('ext_users_send_subforms_list')->middleware(['auth','2fa','is_email_varified']);

Route::post('Forms/AsgnSubFormToExUsers','Forms@assign_subform_to_external_users')->name('assign_subforms_to_external_users');
Route::get('Forms/SubFormsList/{id}','Forms@subforms_list')->name('subforms_list')->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/SubFormToSend/{id}',         'Forms@send_email_subforms_list')
     ->name('subform_to_send')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/AddSubForm/{id}',         'Forms@add_subform')
     ->name('add_subform')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/EditSubform',           'SubformActions@edit_subform')
     ->name('edit_subform')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/DeleteSubform',           'SubformActions@delete_subform')
     ->name('delete_subform')
     ->middleware(['auth','2fa','is_email_varified']);

Route::post('Forms/GenerateSubForm',      'Forms@create_subform')
     ->name('gen_subform')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/CreateTestForm',        'Forms@create_test_user_form')
     ->name('create_test_usr_form');

Route::get('Forms/SendForm/{id}',         'Forms@send_form_link_to_users')
    ->name('send_form_to_users')
    ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/AdminSite',             'AdminController@index')
     ->name('admin_site')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/FormAssignees/{id}',            'Forms@form_assignees')
     ->name('admin_assignees')
     ->middleware(['auth','is_email_varified']);

Route::get('Forms/SubFormAssignees/{id}',            'Forms@subform_assignees')
     ->name('subform_assignees')
     ->middleware(['auth','2fa','is_email_varified']);

Route::post('Forms/AssignFormToClient',            'Forms@assign_form_to_client')
     ->name('assign_form_to_client')
     ->middleware(['auth','2fa','is_email_varified']);

Route::post('Forms/AssignSubFormToUsers',           'Forms@ajax_assign_subform_to_users')
     ->name('assign_subform_to_users')->middleware(['auth','2fa']);

Route::get('Forms/FormsList',            'Forms@forms_list')
     ->name('client_site')
     ->middleware(['auth','2fa','is_email_varified']);
     // Route::get('Forms/FormsList',            function(){dd('asdasdasd');});
// ahmad     // 
Route::get('Forms/All_Generated_Forms',            'Forms@organization_all_forms_list_all')
     ->name('client_site_all_generated_forms')
     ->middleware(['auth','2fa','is_email_varified']);     

Route::get('Forms/CompletedFormsList',            'Forms@completed_forms_list')
     ->name('client_site')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/ViewForm/{id}',         'Forms@view_form')
     ->name('view_form')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/UserSite',              'Forms@user_site')
     ->name('user_site')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Forms/ClientUserFormsList',     'Forms@client_user_subforms_list')
     ->name('client_user_subforms_list')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('FormSettings/SubFormsExpirySettings',   'Forms@show_subforms_expiry_settings')
     ->name('subforms_expiry_settings')
     ->middleware(['auth','2fa','is_email_varified']);

Route::post('FormSettings/SubFormsExpirySettings', 'Forms@save_subforms_expiry_settings')
     ->name('subforms_expiry_settings')
     ->middleware(['auth','2fa','is_email_varified']);

// -------------------------------- SAR FORMS --------------------------------

// Forms/SubFormAssignees/
// Forms/OrgSubFormsList
Route::get('SAR/SubFormAssignees/{id}',            'Forms@subform_assignees')
     ->name('sar_subform_assignees')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('SAR/OrgSubFormsList/{id}',     'Forms@organization_all_forms_list')
     ->middleware(['auth','2fa','is_email_varified'])
     ->name('sar_org_all_forms_list');

Route::get('SAR/CompanyUserForm/{link_id}',         'Forms@in_users_show_form')
 ->name('sar_user_form_link')->middleware(['auth','2fa','is_email_varified']);

Route::get('SAR/ExtUserForm/{client_id}/{user_id}/{client_email}/{subform_id}/{user_email}/{date_time}',         'Forms@ex_users_show_form')
     ->name('sar_ext_user_form_link');


Route::get('SAR/ShowSARAssignees/{form_id}',            'SARForm@assignee_list')
    ->name('show_SAR_assignee_list')
    ->middleware(['auth','2fa','is_email_varified']);

Route::get('SAR/SARCompletedFormsList',            'SARForm@sar_completed_forms_list')->middleware(['auth','2fa','is_email_varified']);

Route::get('SAR/SARInCompletedFormsList',            'SARForm@sar_incompleted_forms_list')->middleware(['auth','2fa','is_email_varified']);


Route::get('FormSettings/SARExpirySettings',             'SARForm@sar_expiry_settings_get')->middleware(['auth','2fa','is_email_varified']);
Route::post('FormSettings/SARExpirySettings',            'SARForm@sar_expiry_settings_post')->middleware(['auth','2fa','is_email_varified']);
Route::post('SAR/ChangeRequestStatus',          'SARForm@change_sar_request_status_post')->middleware(['auth','2fa','is_email_varified']);


// -------------------------------- SAR FORMS --------------------------------

Route::post('/2faverify', function(){
    //return redirect(URL()->previous());
        $role_routes = [
                          //1 => 'admin_site',
                            1 => 'admin_def',
                            2 => 'dashboard',
                            3 => 'dashboard',
                            //3 => 'client_user_subforms_list'
                       ];
                       
        $user_role = Auth::user()->role;               
                       
        if (Auth::user()->user_type == '1'){
            $user_role = 2;
        }

        return redirect(route($role_routes[$user_role]));

})->name('2faverify')->middleware('2fa'); 


// Route::post('/2faverify', function(){
//  return redirect(URL()->previous());
// })->name('2faverify')->middleware('2fa');

Route::get('Forms/TestEmail',            'HomeController@test_email')
     ->name('test_email');

//Route::get('/{company}/login', '');


// wakeel

Route::get('/profile/{id}','PackagesController@profile');


Route::get('/terms', 'HomeController@terms');

Route::get('/privacy', 'HomeController@privacy');

Route::get('/subscriber', 'HomeController@subscriber');

Route::get('/howtoplay', 'HomeController@howtoplay');

Auth::routes();



Route::get('/logout', 'Auth\LoginController@logout');



// Users

Route::get('/users/edit/{id}', 'UsersController@edit');

Route::get('/users/detail/{id}', 'UsersController@detail');

Route::get('/users/add', 'UsersController@addUser');

Route::post('/users/store', 'UsersController@store');

Route::post('/users/delete', 'UsersController@destroy');

Route::post('verify_code', 'HomeController@verify_code');


Route::post('/users/edit_store/{id}', 'UsersController@edit_store');

Route::post('/client/store', 'UsersController@clientStore');

Route::get('/client/add', 'UsersController@addClient');


Route::post('/save_images','PackagesController@save_images')->name('save_images');

Route::post('package/save_related_product','PackagesController@save_related_product');


Route::get('/Forms/SecCategory/{id}', 'Forms@section_category');
Route::post('/Forms/UpdateFormSection/', 'Forms@ajax_update_form_section_heading')
->name('update_form_section_heading');

Route::post('/updateSorting/', 'Forms@updateSorting')
->name('updateSorting');





Route::post('/Forms/AsgnSecCategory/','Forms@assign_section_category')
     ->middleware(['auth','2fa','is_email_varified']);

Route::post('/Forms/AsgnSecCategory/','Forms@assign_section_category')
    ->name('asgn_sec_ctgry')
    ->middleware(['auth','2fa','is_email_varified']);
    
Route::get('/Reports/AssetsReports/{id}',   'Reports@response_reports')
     ->name('assets_reports')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('/Reports/DataInvReports/{id}', 'Reports@response_reports')
     ->name('data_inventory_reports')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('/Reports/AssetsReportsEx/{id}',   'Reports@response_reports_external_users')
     ->name('assets_reports_ex')
     ->middleware(['auth','2fa','is_email_varified']);
     
Route::get('/Reports/DataInvReportsEx/{id}',  'Reports@response_reports_external_users')
     ->name('data_inventory_reports_ex')
     ->middleware(['auth','2fa','is_email_varified']);
     
Route::get('/Reports/AssetsReportsReg/{id}',   'Reports@response_reports_registered_users')
     ->name('assets_reports_in')
     ->middleware(['auth','2fa','is_email_varified']);
     
Route::get('/Reports/DataInvReportsReg/{id}',  'Reports@response_reports_registered_users')
     ->name('data_inventory_reports_in')
     ->middleware(['auth','2fa','is_email_varified']);

Route::get('Reports/SummaryReports', 'Reports@summary_reports_sfw')
     ->name('summary_reports')
     ->middleware(['auth','2fa','is_email_varified']);
     
// Route::get('Reports/CompanyReports', 'Reports@summary_reports_all')
//      ->name('summary_reports_all')
//      ->middleware(['auth','2fa']);
     // 
     // Ahmad
Route::get('Reports/GlobalDataInventory', 'Reports@summary_reports_all')
     ->name('summary_reports_all')
     ->middleware(['auth','2fa' ,'is_email_varified']);

     Route::get('Reports/DetailedDataInventory', 'Reports@summary_reports_all_2')
     ->name('detail_data_inventory_report')
     ->middleware(['auth','2fa' ,'is_email_varified']);
     //
     // 
Route::post('Reports/CompanyReportsPDF', 'Reports@summary_reports_all_PDF')
    ->name('summary_reports_all_pdf')
    ->middleware(['auth','2fa' ,'is_email_varified']);

Route::get('Reports/DownloadCompanyReportsPDF/{pdfname}', 'Reports@download_generated_pdf')
    ->name('download_summary_reports_all_pdf')
    ->middleware(['auth','2fa' ,'is_email_varified']);

Route::get('question',function(){

  return view('admin.question.questionForm');
});

Route::post('reset_password', 'HomeController@reset');

Route::post('/profile/edit','PackagesController@profile_edit');

// Route::get('/send_email/{id}','PackagesController@send_email');

// Route::get('/admin', 'UsersController@index')->name('admin_def');



// -------------------------------- Login Image SETTINGS --------------------------------
Route::get('/login_img_settings', 'HomeController@login_img_settings')->middleware(['auth']);
Route::post('/update_login_img', 'HomeController@update_login_img')->middleware(['auth']);
// -------------------------------- Login Image SETTINGS --------------------------------

// --------------------------------Data Classification --------------------------------
Route::get('/data-classification', 'HomeController@data_classification')->middleware(['auth']);
Route::get('/front/data-classification', 'Forms@data_classification')->middleware(['auth']);
// --------------------------------Data Classification --------------------------------

// --------------------------------Impact --------------------------------
Route::get('/impact', 'HomeController@impact')->middleware(['auth']);
// --------------------------------Impact --------------------------------


// -------------------------------- FORMS SETTINGS --------------------------------
Route::post('/formsettings/unlock_form', 'Forms@unlock_form')->middleware(['auth'])->name('unlock_form');
Route::post('/formsettings/change_form_access', 'Forms@change_form_access')->middleware(['auth'])->name('change_form_access');

// -------------------------------- FORMS SETTINGS --------------------------------





// -------------------------------- ASSETS --------------------------------

Route::get('/assets',    'AssetsController@index')->name('asset_list')->middleware(['auth','2fa' ,'is_email_varified']);
Route::post('/assets',    'AssetsController@index')->name('asset_list')/*->middleware(['auth','2fa' ,'is_email_varified'])*/;
Route::get("assets_data_elements","AssetsController@asset_data_elements")->name("asset_data_elements");
Route::post("/update_asset_data_element","AssetsController@asset_elements_update")->name("update_asset_eleme");
Route::get('/add_asset', 'AssetsController@add_asset')->name('add_asset')->middleware(['auth','2fa' ,'is_email_varified']);
Route::get('/export-asset',"AssetsController@exportAssets");
Route::get('/import-asset',"AssetsController@importAssets");
Route::post('/import-asset-data',"AssetsController@importAssetsData")->name('import');
Route::get('/export-sample-data','AssetsController@exportSampleData');
// Route::get('/del_asset', 'AssetsController@delete_asset')->name('delete_asset')->middleware(['auth']);
Route::post('delete_asset', 'AssetsController@delete_asset')->middleware(['auth']);
Route::post('/asset_update', 'AssetsController@asset_update')->name('asset_update');
Route::post('/asset_add', 'AssetsController@asset_add')->name('asset_add')->middleware(['auth','2fa' ,'is_email_varified']);
Route::post('/update_asset', 'AssetsController@update_asset')->name('update_asset')->middleware(['auth','2fa' ,'is_email_varified']);
Route::get('/asset_delete/{id}', 'AssetsController@asset_delete');
Route::get('/asset_edit/{id}', 'AssetsController@asset_edit')->name('asset_edit')->middleware(['auth','2fa' ,'is_email_varified']);
Route::post('/asset_edit/{id}', 'AssetsController@asset_edit');
Route::get("/view-assets/{id}","AssetsController@view_assets");
// Ajax call
Route::post("asset_matrix_tier","AssetsController@asset_matrix")->name("getData");


// -------------------------------- ASSETS --------------------------------
// -------------------------------- ACTIVITIES --------------------------------

Route::get('/activities',    'ActivitiesController@index')->name('activity_list')->middleware(['auth','2fa','is_email_varified']);

// -------------------------------- ACTIVITIES --------------------------------

Route::get('/Orgusers/permissions/{id}', 'Forms@permissions')->middleware(['auth','is_email_varified']);
Route::post('orgusers/permissions/store', 'Forms@permissions_store')->middleware(['auth','is_email_varified']);




// });

Route::group(["middleware" => 'admin'], function () {
    
Route::get('/admin',             'UsersController@index')->name('admin_def');
Route::get('/site_admins',       'Admin@site_admins')->name('site_admins');
Route::get('/add_admin',         'Admin@add_admin')->name('add_admin');
Route::post('/add_admin',        'Admin@add_admin_act')->name('add_admin_act');
Route::get('/edit_admin/{id}',   'Admin@edit_admin')->name('edit_admin');
Route::post('/edit_admin/{id}',  'Admin@edit_admin_act')->name('edit_admin_act');
Route::get('edit_form/{id}',     'Admin@edit_form')->name('edit_form_info');
Route::post('edit_form/{id}',    'Admin@edit_form_act')->name('edit_form_info_act');

//Edit form classification
Route::get('edit-classification/{id}',     'Admin@edit_classification')->name('edit_classification');
Route::post('edit-classification/{id}',    'Admin@edit_classification_act')->name('edit_classification_act');
//Edit form classification

//Edit form classification
Route::get('edit-impact/{id}',     'Admin@edit_impact')->name('edit_impact');
Route::post('edit-impact/{id}',    'Admin@edit_impact_act')->name('edit_impact_act');
//Edit form classification

Route::get('/company', 'UsersController@company')->middleware(['auth']); 

Route::get('selectClient', 'PackagesController@index')->middleware(['auth']);

Route::get('client', 'PackagesController@client')->middleware(['auth']);

Route::post('saveClient/{id}', 'PackagesController@saveClient')->middleware(['auth']);

Route::get('client/user/{id}', 'PackagesController@showUser')->middleware(['auth']);


Route::get('/users/edit/{id}', 'UsersController@edit');
// Route::get('/orgUser/permission/{id}', 'Forms@addPermission')->middleware(['auth']);

Route::get('/users/edit_company/{id}', 'UsersController@edit_company')->middleware(['auth']);
Route::get('/users/permissions/{id}', 'UsersController@permissions')->middleware(['auth']);
Route::get('/users/detail/{id}', 'UsersController@detail')->middleware(['auth']);
Route::get('/users/add/{id}', 'UsersController@addUser')->middleware(['auth']);
Route::post('/users/store', 'UsersController@store')->middleware(['auth']);
Route::post('users/permissions/store', 'UsersController@permissions_store')->middleware(['auth']);
Route::post('/users/delete', 'UsersController@destroy')->middleware(['auth']);
Route::post('/users/edit_store/{id}', 'UsersController@edit_store')->middleware(['auth']);
Route::post('/users/editCompany_store/{id}', 'UsersController@editCompany_store')->middleware(['auth']);
Route::post('/client/store', 'UsersController@clientStore')->middleware(['auth']);
Route::get('/client/add', 'UsersController@addClient')->middleware(['auth']);
Route::get('Forms/AdminFormsList/{type?}',            'Forms@all_forms_list')
     ->name('admin_forms_list')->middleware(['auth']);

Route::get('Forms/AdminFormsList','Forms@all_forms_list')->name('admin_forms_list')->middleware(['auth']);

Route::get('Forms/Add-new-form',            'Forms@add_new_form')
     ->name('add_new_form')->middleware(['auth']);
Route::post('Forms/Add-new-form',            'Forms@store_new_form')
     ->name('store_new_form')->middleware(['auth']);
Route::get('Forms/{form_id}/add/questions',            'Forms@add_form_questions')
     ->name('add_form_questions')->middleware(['auth']);

Route::post('change_question_title','Forms@chnageQuestionLabel')
     ->name('chnageQuestionLabel')->middleware(['auth']);
Route::post('update_cc_options','Forms@update_cc_options')->name('update_cc_options')->middleware(['auth']);
Route::post('update_sc_comment','Forms@update_sc_comment')->name('update_sc_comment')->middleware(['auth']);




Route::post('form/add/section/to/form',            'Forms@add_section_to_form')
     ->name('add_section_to_form')->middleware(['auth']);
Route::post('form/add/question/to/form',            'Forms@add_question_to_form')
     ->name('add_question_to_form')->middleware(['auth']); 
Route::post('form/add/special_question/to/form',            'Forms@add_special_question_to_form')
     ->name('add_special_question_to_form')->middleware(['auth']);  
Route::post('update_options', 'Forms@update_options')->name('update_options')->middleware(['auth']);
Route::post('update_options_fr', 'Forms@update_options_fr')->name('update_options_fr')->middleware(['auth']);  

Route::post('change_question_comment', 'Forms@change_question_comment')->name('change_question_comment')->middleware(['auth']); 
Route::post('delete_question', 'Forms@delete_question')->name('delete_question')->middleware(['auth']); 

 

/*follow for captcha*/
Route::get('reload-captcha','HomeController@reloadCaptcha');

/*end for captcha*/

      



});