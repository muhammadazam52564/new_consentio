<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Packages Lines
    |--------------------------------------------------------------------------
    |
    
    */
    
    'packages'         => 'Packages',
    'add_new_packages'         => 'Add New Packages',
    'package'         => 'Package',
    'name'            => 'Name',
    'price'            => 'Price',
    'actions'            => 'Actions',
    'add_new'          => 'Add New',
    'packages_listing' => 'Packages Listings',
    'delete_package'        => 'Delete Package',
    'delete_package_msg'        => 'Are you sure you want to delete?',
    'success_delete'        => 'Deleted',
    'update'         => 'Update',
    'update'         => 'Update Package',
    'time_period'         => 'Time Period',
    

];
