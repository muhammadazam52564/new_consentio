@extends('admin.client.client_app')

@section('content')
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<table class="table-striped table-bordered">
					<thead>
						<tr>
              
              <th scope="col" col-span="2" >Data Classification Name English </th>
              <th scope="col" col-span="2" >Data Classification Name French </th>
              <?php if (Auth::user()->role == 1): ?>
              <th scope="col">Actions</th>
              <?php endif; ?>

            </tr>
					</thead>	
						<tbody class="btn-table" >
							 <?php foreach ($data as $class): ?>
            <tr>
              <td>{{ $class->classification_name_en }}</td>
               <td>{{ $class->classification_name_fr }}</td>
             
               
             
               <?php if (Auth::user()->role == 1): ?>
              <td><a href="{{url('edit-classification/'.$class->id)}}"> <i class="fas fa-pencil-alt"></i> Edit</a></td>
              <?php endif; ?>
              
            </tr>
            <?php endforeach; ?>
								
						</tbody>	
				</table>
			</div>
		</div>
	</div>	

<script type="text/javascript">
	function update_asset_element(id){
		var ase_id = $("#ade_id_"+id).val();
		/*var name = $("#ade_name_"+id).val();
		var order_sort = $("#order_sort_"+id).val();
		var dc_id = $("#dc_id_"+id).val();*/

		$.ajax({
			method: "POST",
			url: "{{url('update_asset_data_element')}}",
			data: {ae_id:$("#ade_id_"+id).val(),asset_name:$("#ade_name_"+id).val(),sort:$("#order_sort_"+id).val(),d_c_id:$("#dc_id_"+id).val(),"_token":"{{csrf_token()}}"},
			success:function(data){
				console.log(data);
			}
		})
	}
</script>
@endsection