<h1>asdasdasdsad</h1>

<img src="{{$path}}">