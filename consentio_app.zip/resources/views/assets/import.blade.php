@extends ('admin.client.client_app')

@section('content')
	
		<form action="{{route('import')}}" method="post" enctype="multipart/form-data">
			{{ csrf_field() }}
			 <div class="form-group" >
			 	<label for="">Import Asset File</label>
			 	<input type="file" name="import_file" id="import_file" class="form-control">
			 </div>
			 <div class="form-group">
			 	<button type="submit" class="btn btn-primary">Import Data</button>
			 	<a href="{{url('export-sample-data')}}" class="btn btn-success float-right">Sample Data</a>
			 </div>
		</form>
		

@endsection