@extends('admin.client.client_app')

@section('content')
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<table class="table-striped table-bordered">
					<thead class="text-center">
						<tr>
							<th>Data Elements</th>
							<th>Data Element group</th>
							<th>Data Classification</th>
							
							<th>Action</th>
						</tr>
					</thead>	
						<tbody class="btn-table" >
							@foreach($data as $val)
								<form action="" method="post">
									 {{ csrf_field() }}
									<tr>
										<td>

											<input type="hidden" class="ade_name" id="ade_id_{{$val->id}}" value="{{$val->id}}" class="form-control">
											<input type="text" class="ade_name" id="ade_name_{{$val->id}}" value="{{$val->name}}" class="form-control">
										</td>
										<td>
											<select name="section_id" id="section_id_{{$val->id}}">
												@foreach($section as $sec)
													<option value="{{$sec->id}}" {{$sec->id == $val->section_id ? "selected":""}}>{{$sec->section_name}}</option>
												@endforeach

											</select>
										</td>
										<td><select name="dc_id" class="dc_id" id="dc_id_{{$val->id}}" class="form-control">
											@foreach ($dc_data as $dc)
													<option  value="{{$dc->id}}" {{$dc->id == $val->d_classification_id ? "selected":""}}>{{$dc->classification_name_en}}</option>
											@endforeach 
										</select></td>
										<td><button type="button"  id="update_button" onclick="update_asset_element({{$val->id}})"  class="btn btn-primary update_button text-light">Update</button></td>
									</tr>	
								</form>		
							@endforeach	
								
						</tbody>	
				</table>
			</div>
		</div>
	</div>	

<script type="text/javascript">
	function update_asset_element(id){
		var ase_id = $("#ade_id_"+id).val();
		/*var name = $("#ade_name_"+id).val();
		var order_sort = $("#order_sort_"+id).val();
		var dc_id = $("#dc_id_"+id).val();*/

		$.ajax({
			method: "POST",
			url: "{{url('update_asset_data_element')}}",
			data: {ae_id:$("#ade_id_"+id).val(),asset_name:$("#ade_name_"+id).val(),section:$("#section_id_"+id).val(),d_c_id:$("#dc_id_"+id).val(),"_token":"{{csrf_token()}}"},
			success:function(data){
				console.log(data);
			}
		})
	}
</script>
@endsection